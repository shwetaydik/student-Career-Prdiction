import numpy as np
import pickle

loaded_model=pickle.load(open('C:/Users/shwet/OneDrive/Desktop/st/train_model.sav','rb'))

list1=[1 ,1, 0, 1, 0, 1, 0 ,1 ,1 ,0, 1 ,1 ,1]
arr=np.array(list1)
print(arr)
t=arr.reshape(1,-1)
y_predicted = loaded_model.predict(t)
predict=y_predicted[0]
predict