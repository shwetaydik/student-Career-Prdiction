#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd 
import seaborn as sns 
import matplotlib.pyplot as plt

df=pd.read_csv("C:/Users/shwet/OneDrive/Desktop/Parisa/data.csv")
df.shape


# In[2]:


df['Introvert'].value_counts()


# In[3]:


df[df['Interested subjects']=="Management"]['Suggested Job Role'].value_counts()


# In[4]:


for i in df.columns[:9]:
  plt.figure(figsize=(10, 1))
  sns.boxplot(df[i])
  plt.show()


# In[5]:


plt.figure(figsize=(10, 5))
sns.countplot(x='Gentle or Tuff behaviour?',hue="Introvert", data=df)
plt.show()


# In[6]:


plt.figure(figsize=(10, 5))
sns.countplot(x='Management or Technical',data=df)
plt.show()


# In[7]:


plt.figure(figsize=(10, 5))
sns.countplot(y='Interested subjects',hue="Extra-courses did",data=df)
plt.show()


# In[8]:


df.isnull().sum()


# In[ ]:





# In[9]:


df.describe()


# In[ ]:





# Data Preprocessing

# In[10]:


df['public speaking points'].value_counts()
df[df['public speaking points']>=5].index

for i in df[['public speaking points']].index:
  if(df.loc[i,'public speaking points']>=5):
    df.loc[i,'public speaking']=1
  else:
    df.loc[i,'public speaking']=0


df=df.astype({"public speaking": int}) 

df[['public speaking points','public speaking']]
df.columns


# In[11]:


df["Introvert"]=pd.Series([1 if i=='yes' else 0 for i in df["Introvert"] ])
df["Job/Higher Studies?"]=pd.Series([1 if i=='higherstudies' else 0 for i in df['Job/Higher Studies?'] ])


# In[12]:


for i in df.columns[0:9]:
  for j in df[i].index:
    if df.loc[j,i]>=75:
      df.loc[j,i]=1
    elif (df.loc[j,i]<75)& (df.loc[j,i]>=60):
      df.loc[j,i]=0
    else:
      df.loc[j,i]=2


# In[13]:


df['Management or Technical']=pd.Series([1 if i=='Technical' else 0 for i in df['Management or Technical'] ])
df['Management or Technical'].value_counts()


# In[14]:


df.columns


# In[15]:


df_new=df[['Acedamic percentage in Operating Systems', 'percentage in Algorithms',
       'Percentage in Programming Concepts',
       'Percentage in Software Engineering', 'Percentage in Computer Networks',
       'Percentage in Electronics Subjects',
       'Percentage in Computer Architecture', 'Percentage in Mathematics',
       'Percentage in Communication skills','public speaking','Introvert',"Job/Higher Studies?",'Management or Technical']]
df_new.head()


# In[16]:


for i in range(0,12913):
  if (df_new.loc[i,'Job/Higher Studies?']==0):

    if (df_new.loc[i,'Percentage in Communication skills']==1)&(df_new.loc[i,'public speaking']==1)&(df_new.loc[i,'Percentage in Mathematics']==2)&(df_new.loc[i,'Percentage in Programming Concepts']==2):
       df_new.loc[i,"LABEL"]="Business Analyst"

    if (df_new.loc[i,'Percentage in Communication skills']==1)&(df_new.loc[i,'public speaking']==0)&(df_new.loc[i,'Percentage in Mathematics']==1)&(df_new.loc[i,'Percentage in Programming Concepts']==1):  
      df_new.loc[i,"LABEL"]="Data Analyst"

    if (df_new.loc[i,'Percentage in Communication skills']==1)&(df_new.loc[i,'public speaking']==1)&(df_new.loc[i,'Percentage in Mathematics']==1)&(df_new.loc[i,'Percentage in Programming Concepts']==1):  
      df_new.loc[i,"LABEL"]=" Data Scientist"
    
    if (df_new.loc[i,'Percentage in Computer Architecture']==1)&(df_new.loc[i,'Acedamic percentage in Operating Systems']==1)&(df_new.loc[i,'public speaking']==0)&(df_new.loc[i,'Percentage in Programming Concepts']==0):  
      df_new.loc[i,"LABEL"]=" Design & UX"

    if (df_new.loc[i,'Percentage in Software Engineering']==1)&(df_new.loc[i,'percentage in Algorithms']==1)&(df_new.loc[i,'Acedamic percentage in Operating Systems']==1)&(df_new.loc[i,'Percentage in Programming Concepts']==1)&(df_new.loc[i,'public speaking']==0):  
      df_new.loc[i,"LABEL"]=" Software Developer"

    if (df_new.loc[i,'percentage in Algorithms']==1)&(df_new.loc[i,'Percentage in Programming Concepts']==1):  
      df_new.loc[i,"LABEL"]=" Web Developer"
    
    if (df_new.loc[i,'Percentage in Computer Networks']==1)&(df_new.loc[i,'Percentage in Electronics Subjects']==1):  
      df_new.loc[i,"LABEL"]=" Network Security"
    if (df_new.loc[i,'Percentage in Communication skills']==2)&(df_new.loc[i,'public speaking']==0)&(df_new.loc[i,'Percentage in Mathematics']==1)&(df_new.loc[i,'Percentage in Programming Concepts']==1):  
      df_new.loc[i,"LABEL"]="Data Analyst"
    if (df_new.loc[i,'Percentage in Communication skills']==2)&(df_new.loc[i,'Percentage in Mathematics']==2)&(df_new.loc[i,'Percentage in Programming Concepts']==2):  
      df_new.loc[i,"LABEL"]=" Non Technical Domain"
    
  else:

    if (df_new.loc[i,'Management or Technical']==0):
      if (df_new.loc[i,'public speaking']==1):  
        df_new.loc[i,"LABEL"]=" Project Manager "
      else:
        df_new.loc[i,"LABEL"]=" Human Resource "
    else:
      if (df_new.loc[i,'Percentage in Communication skills']==1)&(df_new.loc[i,'public speaking']==1)&(df_new.loc[i,'Percentage in Mathematics']==1)&(df_new.loc[i,'Percentage in Programming Concepts']==1):  
        df_new.loc[i,"LABEL"]=" Data Scientist"
      if (df_new.loc[i,'Percentage in Software Engineering']==1)&(df_new.loc[i,'percentage in Algorithms']==1)&(df_new.loc[i,'Acedamic percentage in Operating Systems']==1)&(df_new.loc[i,'Percentage in Programming Concepts']==1)&(df_new.loc[i,'public speaking']==0):  
        df_new.loc[i,"LABEL"]=" Software Developer"
      else:
        df_new.loc[i,"LABEL"]=" Senior Engineer "

for i in df[df_new['LABEL'].isnull()==True].index:
  df_new.loc[i,'LABEL']='Non Technical Domain'   


# In[17]:


df_new.columns


# In[18]:


value = df_new['LABEL']
df_new.insert(loc=0, column='Career', value=value)
df_new.head()


# In[19]:


df_new = df_new.drop(columns=['LABEL'], axis=1) 


# In[20]:


df_new.head()


# In[21]:


import seaborn as sns
import matplotlib.pyplot as plt
data_science=['Percentage in Communication skills','public speaking','Percentage in Mathematics','Percentage in Programming Concepts']
for i in data_science:
  plt.figure(figsize=(10, 5))
  sns.countplot(x=i, hue='Introvert',data=df_new)
  plt.show()


# In[22]:


plt.figure(figsize=(10, 5))
sns.countplot(y='Career',data=df_new)
plt.show()


# In[23]:


plt.figure(figsize=(10, 5))
sns.countplot(y='Career',hue='Management or Technical',data=df_new)
plt.show() 


# Model Implementation

# In[24]:


from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.model_selection import train_test_split


# In[25]:


#x_train = df_new.iloc[:, :-1]
#x_train.head()


# In[26]:


#y_train = df_new.loc[:, 'LABEL']
#y_train


# In[27]:


#y_test =df_new.loc[0:1000, 'LABEL']
#y_test.head(30)


# In[28]:


x=df_new.iloc[:,1:]
y=df_new.iloc[:,0]


# In[29]:


X_train, X_test, Y_train, Y_test = train_test_split(x, y, test_size=0.1)


# In[30]:


Y_test


# In[31]:


#x_test = df_new.iloc[:1000, :-1]


# In[32]:


rf_clf = RandomForestClassifier(n_jobs=-1, n_estimators=50)
rf_clf.fit(X_train.values,Y_train.values)
rf_clf.score(X_train.values,Y_train.values)


# 

# In[38]:


import pickle
filename='train_model.sav'
pickle.dump(rf_clf,open(filename,'wb'))


# In[39]:


loaded_model=pickle.load(open('train_model.sav','rb'))


# In[35]:


import streamlit as st
import pickle


# In[36]:


model1=pickle.load(open)


# In[40]:



import numpy as np
list1=[]
for i in X_test.columns:
  input1=int(input(f"Are You  interested in {i} 1 for YES,  0 for No"))
  list1.append(input1)
arr=np.array(list1)
print(arr)
t=arr.reshape(1,-1)


# In[41]:


y_predicted = loaded_model.predict(t)
predict=y_predicted[0]
predict


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


y_predicted=rf_clf.predict(X_test)


# In[ ]:


print(classification_report(Y_test, y_predicted))


# In[ ]:


import xgboost as xg

model = xg.XGBClassifier()
model.fit(X_train,Y_train)
model.score(X_train,Y_train)


# User Interface

# In[ ]:



import numpy as np
list1=[]
for i in X_test.columns:
  input1=int(input(f"Are You  interested in {i} 1 for YES,  0 for No"))
  list1.append(input1)
arr=np.array(list1)
print(arr)
t=arr.reshape(1,-1)


# In[ ]:


y_predicted = rf_clf.predict(t)
predict=y_predicted[0]
predict

