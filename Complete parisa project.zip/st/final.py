import numpy as np
import pickle
import streamlit as st
loaded_model=pickle.load(open('C:/Users/shwet/OneDrive/Desktop/st/train_model.sav','rb'))

#creatin function
def careerprediction(input_data):

    arr = np.array(input_data)
    t = arr.reshape(1, -1)
    y_predicted = loaded_model.predict(t)
    predict = y_predicted[0]
    return predict
'''
Having a career that aligns with who you are will make you an energetic, positive, and makes your life outside of work better.'
'''

def main():
    st.title("Career Prediction Web App")

    #getting input data from user


    operating_sys=st.number_input(" Good or bad in OS",min_value=0,max_value=1,step=1)
    Algorithms = st.number_input(" Good or bad in  Algorithms",min_value=0,max_value=1,step=1)
    Programming_Concepts = st.number_input(" Good or bad inProgramming_Concepts ",min_value=0,max_value=1,step=1)
    Software_Engineering = st.number_input(" Good or bad in Software_Engineering",min_value=0,max_value=1,step=1)
    Computer_Networks= st.number_input(" Good or bad in Computer_Networks",min_value=0,max_value=1,step=1)
    electronics_Subjects= st.number_input(" Good or bad in electronics_Subjects ",min_value=0,max_value=1,step=1)
    Computer_Architecture=st.number_input(" Good or bad in Computer_Architecture",min_value=0,max_value=1,step=1)
    Mathematics = st.number_input(" Good or bad in  Mathematics",min_value=0,max_value=1,step=1)
    Communication_skills = st.number_input(" Good or bad in Communication_skills",min_value=0,max_value=1,step=1)
    public_speaking = st.number_input(" Interested  public_speaking",min_value=0,max_value=1,step=1)
    Introvert =st.number_input(" Are you an Introvert",min_value=0,max_value=1,step=1)
    Job_Higher_Studies = st.number_input(" Wanna go for Job_Higher_Studies",min_value=0,max_value=1,step=1)
    Management_Technical =st.number_input(" Interested field Management_Technical",min_value=0,max_value=1,step=1)

    list1=[operating_sys, Algorithms, Programming_Concepts, Software_Engineering, Computer_Networks, electronics_Subjects,
     Computer_Architecture, Mathematics, Communication_skills, public_speaking, Introvert, Job_Higher_Studies,
     Management_Technical]
    list2=[]
    for i in list1:
       if  i==1:
           s=nameof(i)
           list2.append(s)
   



#code for prediction
    cr=''
# button for prdiction
    if st.button("Career Prediciton"):
        cr=careerprediction([operating_sys,Algorithms,Programming_Concepts,Software_Engineering,Computer_Networks,electronics_Subjects,Computer_Architecture,Mathematics,Communication_skills,public_speaking,Introvert,Job_Higher_Studies,Management_Technical])
    for i in list2:
        st.markdown(f""" 
         {i}: 'Good'

           """)
    st.success(cr)


if __name__=='__main__':
    main()
